package components;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel extends JPanel{
	private String nameField;
String name;
	
	public Panel(String name) {
		this.setBackground(new Color(213,167,113));
		this.name = name;
		this.setLayout(null);
		
	}
	
	
	
	
}
