package components;

import javax.swing.JTable;

public class Table extends JTable{

	public Table() {
		
	}
	
	
	
}
