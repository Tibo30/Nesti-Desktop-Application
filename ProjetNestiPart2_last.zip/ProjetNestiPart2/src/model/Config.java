package model;

public class Config {
	
	protected static final String USERNAME= "root";
	protected static final String PASSWORD = "";
	protected static final String DATABASE = "java_nesti";
	protected static final String HOSTNAME= "127.0.0.1";
}
